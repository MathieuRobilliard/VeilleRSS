<!--
This file show all categories of a user.
-->

<?php include("header.php"); ?>

<body>
			<?php include("./ViewNavbar.php"); ?>
			<?php include("./../Controller/ControllerCategories.php"); ?>
</body>

<?php include("footer.php"); ?>
