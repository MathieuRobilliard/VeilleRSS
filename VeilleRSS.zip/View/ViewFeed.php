<!--
This file show all flux RSS of the web site.
-->


<?php include("header.php"); ?>

<body>
		<?php include("./ViewNavbar.php"); ?>
		<?php include("./../Controller/ControllerFeed.php"); ?>




</body>

<?php include("footer.php"); ?>
