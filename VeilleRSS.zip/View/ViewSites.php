<!--
This file show all sites about the category selected.
-->

<?php include("header.php"); ?>

<body>
		<?php include("./ViewNavbar.php"); ?>
		<?php include("./../Controller/ControllerSites.php"); ?>

</body>

<?php include("footer.php"); ?>
