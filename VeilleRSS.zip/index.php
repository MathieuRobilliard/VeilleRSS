<!DOCTYPE html>
<html lang="en">
<body>

<?php
header('Location: ./View/HomePage.php');
?>
	
</body>
</html>